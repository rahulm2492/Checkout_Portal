import React from 'react';
import data from '../../data.js';



class Row extends React.Component {

  constructor(){
      super();
      this.arr = [];  
    
    } 

   getRow(item,disp){
     return( 
     <tr style={{display:disp}}>
      <td>+</td>
      <td>{item.id}</td>
      <td>{item.name}</td>
      <td>{item.designation}</td>
      </tr>);

   }

   dataMap(item, display){
      item.map((d)=> {
      this.arr.push(this.getRow(d, display));
      if(d.children && d.children.length) {
          this.dataMap(d.children,'none');
      }
    })
}
   

    render(){
        this.dataMap(data)
    console.log(this.arr,this.arr.length);
      return(
     
        this.arr
      )}


    

}

export default Row;