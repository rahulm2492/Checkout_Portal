(function(){

    
  
  var lives = 3;
  var timeLimitInMinutes = 1;
  this.view = new app.View();
  this.modal = new app.Modal(lives,timeLimitInMinutes);
  this.control = new app.Control(this.view, this.modal);

  document.getElementById('startStop').addEventListener('click',function(){control.startGame()})

})();