(function(window){
    
    
      function Modal(lives,timeLimit){
          this.lives = lives;
          this.timeLimit = timeLimit;
       
      }

      Modal.prototype.decrementLife = function(){
        this.lives = this.lives -1;
      }

      


       
    
      window.app = window.app || {};
      window.app.Modal = Modal;
    })(window);