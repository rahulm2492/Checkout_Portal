(function(window){
    
    
      function View(randomNumber){
        this.template = new app.Template(randomNumber);
      
      }

      View.prototype.render = function(lives,timeLimit,arr){

          this.template.setLives(lives);
          this.template.setBoard(arr);

         
         document.getElementById('main').innerHTML = this.template.board;
         document.getElementById('control').insertAdjacentHTML( 'afterbegin', this.template.hearts + this.template.ticker);
         document.getElementById('timeLeft').innerHTML = timeLimit + ':00';


      }

      View.prototype.rerender = function(lives,timeLimit,arr){
        this.template.setBoard(arr);
        document.getElementById('main').innerHTML = this.template.board;
        document.getElementById('timeLeft').innerHTML = timeLimit + ':00';

      }
      
      View.prototype.getRedBlocks = function(){
        return document.querySelectorAll('td.red');
      }

      View.prototype.startEvent = function(){
        document.getElementById('board').addEventListener('click',function(e){
        e.target.id === 'miniBlock' ? (e.target.className === 'red' ? 
                                          e.target.className = 'white': 
                                          e.target.className = 'red')
                                       : null;   
        });
      }


       
    
      window.app = window.app || {};
      window.app.View = View;
    })(window);