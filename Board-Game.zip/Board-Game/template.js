(function(window){


  function Template(){
   this.hearts = '';
   this.ticker = '<p>Time left <span id = "timeLeft">5:00</span> seconds</p>';
   this.blocks = [];
   this.board = '';
  }

 Template.prototype.setLives = function(limit){
     var lives = ''
    
     for(var i = 0; i< limit;i++){
        lives = lives + '<li><svg class="heart" viewBox="0 0 32 29.6">'+
        '<path d="M23.6,0c-3.4,0-6.3,2.7-7.6,5.6C14.7,2.7,11.8,0,8.4,0C3.8,0,0,3.8,0,8.4c0,9.4,9.5,11.9,16,21.2'+
          'c6.1-9.3,16-12.1,16-21.2C32,3.8,28.2,0,23.6,0z"/></svg> </li>';
     }
     this.hearts = '<ul>'+lives+'</ul>'; 
 }

 Template.prototype.setBoard = function(arr){
    if(arr) this.blocks = arr;
    var row = '';
    for(var i = 0; i< this.blocks.length; i++){
        var miniBlocks = '';
        for(var j = 0; j< this.blocks.length; j++){
            if(this.blocks.indexOf(''+i+j)>-1) {
                miniBlocks = miniBlocks+'<td id="miniBlock" class="red"></td>';
            }
            else {
                miniBlocks = miniBlocks+'<td id="miniBlock" class="white"></td>';
            }
         }
         row = row +  '<tr>'+ miniBlocks + '</tr>';
    }
    this.board = '<table  id="board">'+row+'</table>'; 
}
   
   
  window.app = window.app || {};
  window.app.Template = Template;
})(window);